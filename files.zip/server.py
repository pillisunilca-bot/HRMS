#!/usr/bin/env python3
"""DS HRMS server - Python standard library only.
Run:  python server.py            then open http://127.0.0.1:8080
Options: --port 8080  --host 127.0.0.1   (use --host 0.0.0.0 to let other computers on your network connect)"""
import argparse, base64, datetime, hashlib, hmac, io, json, os, re, secrets, sqlite3, threading, time, traceback, zipfile
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape as xesc
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from http.cookies import SimpleCookie

os.umask(0o077)                                     # the database file is readable only by the service user
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo(os.environ.get('HRMS_TZ', 'Asia/Kolkata'))   # servers such as AWS EC2 run on UTC; business dates follow this zone
except Exception:
    TZ = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
WEBHOOK = os.environ.get('HRMS_WEBHOOK', '').strip()   # optional: every alert is also POSTed here (WhatsApp / SMS / e-mail gateway, Zapier, Make ...)
BEHIND = os.environ.get('HRMS_PROXY') == '1'        # set to 1 when running behind an HTTPS reverse proxy (Caddy / Nginx / load balancer)
HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get('HRMS_DB', os.path.join(HERE, 'hrms.db'))
LOCK = threading.Lock()
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row
db.executescript('''
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS users(u TEXT PRIMARY KEY, name TEXT, salt TEXT, h TEXT, role TEXT, branch TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS sess(t TEXT PRIMARY KEY, u TEXT, exp REAL);
CREATE TABLE IF NOT EXISTS att(c TEXT, d TEXT, s TEXT, PRIMARY KEY(c, d));
CREATE TABLE IF NOT EXISTS lr(id INTEGER PRIMARY KEY AUTOINCREMENT, c TEXT, f TEXT, t2 TEXT, d REAL, r TEXT, s TEXT, by TEXT, ts TEXT);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, u TEXT, a TEXT, x TEXT);''')

for _c in ("emp TEXT DEFAULT ''", "must INTEGER DEFAULT 0"):       # upgrade older databases
    try: db.execute('ALTER TABLE users ADD COLUMN ' + _c)
    except sqlite3.OperationalError: pass
db.execute('CREATE TABLE IF NOT EXISTS pay(c TEXT, m TEXT, j TEXT, PRIMARY KEY(c, m))')
db.execute('CREATE TABLE IF NOT EXISTS ar(id INTEGER PRIMARY KEY AUTOINCREMENT, c TEXT, d TEXT, s TEXT, st TEXT, by TEXT, ts TEXT)')
db.execute('CREATE TABLE IF NOT EXISTS decl(c TEXT, fy INTEGER, j TEXT, st TEXT, note TEXT, ts TEXT, PRIMARY KEY(c, fy))')                    # investment declarations
db.execute('CREATE TABLE IF NOT EXISTS proof(id INTEGER PRIMARY KEY AUTOINCREMENT, c TEXT, fy INTEGER, name TEXT, mime TEXT, data BLOB, ts TEXT)')   # proof documents
db.execute('CREATE TABLE IF NOT EXISTS notif(id INTEGER PRIMARY KEY AUTOINCREMENT, u TEXT, msg TEXT, ts TEXT, rd INTEGER DEFAULT 0)')                 # in-app alerts
db.execute('CREATE TABLE IF NOT EXISTS movs(id INTEGER PRIMARY KEY AUTOINCREMENT, c TEXT, kind TEXT, eff TEXT, j TEXT, ref TEXT, by TEXT, ts TEXT)')   # increments, promotions, transfers
db.execute('CREATE TABLE IF NOT EXISTS inct(c TEXT, m TEXT, tgt REAL, ach REAL, PRIMARY KEY(c, m))')                                                    # monthly targets / achievements
db.execute('CREATE TABLE IF NOT EXISTS paid(m TEXT, b TEXT, d TEXT, by TEXT, ts TEXT, PRIMARY KEY(m, b))')                                              # salary paid, per month and branch
db.execute('CREATE TABLE IF NOT EXISTS fnf(c TEXT PRIMARY KEY, j TEXT, ts TEXT, by TEXT)')                                                       # full & final settlements
for _t, _c in (('ar', 'sess'), ('ar', 'lt'), ('ar', 'wh'), ('ar', 'pu'), ('ar', 'lat'), ('ar', 'lng'), ('ar', 'acc'), ('ar', 'photo'), ('ar', 'apby'), ('ar', 'apts'), ('lr', 'lt'), ('lr', 'hs')):   # upgrade older databases
    try: db.execute('ALTER TABLE %s ADD COLUMN %s TEXT' % (_t, _c))
    except sqlite3.OperationalError: pass
try: db.execute("UPDATE ar SET photo='' WHERE photo!='' AND d < date('now','-90 day')"); db.commit()   # check-in selfies are kept for 90 days
except sqlite3.Error: pass
try: db.execute("DELETE FROM notif WHERE ts < date('now','-60 day')"); db.commit()
except sqlite3.Error: pass
LTYPES = ('CL', 'SL', 'EL')                          # casual / sick / earned leave
SESS = ('Morning', 'Afternoon')
ROLES = ('admin', 'hr', 'payroll', 'management', 'branch', 'employee')
FULL = {'admin', 'hr', 'payroll', 'management'}      # may read all data
WCORE = {'admin', 'hr', 'payroll'}                   # may change employees / payroll / settings
WATT = {'admin', 'hr'}                               # may correct attendance for any branch
STATUS = {'P', 'A', 'L', 'HD', 'OD', 'WO', 'H'}
CORE_KEYS = ('emps', 'br', 'set', 'cyc', 'bal', 'hist', 'enc', 'ye', 'co', 'hol', 'des')
FAILS = {}


class Err(Exception):
    def __init__(s, code, msg): s.code, s.msg = code, msg


today = lambda: os.environ.get('HRMS_TODAY') or datetime.datetime.now(TZ).date().isoformat()   # HRMS_TODAY is for testing only
now = lambda: datetime.datetime.now(TZ).strftime('%Y-%m-%d %H:%M:%S')
hpw = lambda p, salt: hashlib.pbkdf2_hmac('sha256', p.encode(), bytes.fromhex(salt), 200000).hex()


def kv_get(k, default=None):
    r = db.execute('SELECT v FROM kv WHERE k=?', (k,)).fetchone()
    return json.loads(r['v']) if r else default


def kv_set(k, v): db.execute('INSERT OR REPLACE INTO kv VALUES(?,?)', (k, json.dumps(v)))
def audit(u, a, x=''): db.execute('INSERT INTO audit(ts,u,a,x) VALUES(?,?,?,?)', (now(), u, a, x))


def mkuser(u, name, p, role, branch='', emp='', must=0):
    salt = secrets.token_hex(16)
    db.execute('INSERT INTO users(u,name,salt,h,role,branch,active,emp,must) VALUES(?,?,?,?,?,?,1,?,?)', (u, name, salt, hpw(p, salt), role, branch, emp, must))


def col(n):
    r = ''
    n += 1
    while n: n, k = divmod(n - 1, 26); r = chr(65 + k) + r
    return r


def clean(v): return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', str(v))


def make_xlsx(sheets):
    """Minimal .xlsx writer (standard library). sheets = [{n, h, r, f}]"""
    M = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    parts = {'[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + ''.join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1) for i in range(len(sheets))) + '</Types>',
             '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
             'xl/styles.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="%s"><fonts count="3"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font><font><b/><sz val="10"/><name val="Arial"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F3864"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' % M}
    names = []
    for i, sh in enumerate(sheets):
        nm = re.sub(r'[\[\]:*?/\\]', ' ', str(sh.get('n') or 'Sheet%d' % (i + 1)))[:31].strip() or 'Sheet%d' % (i + 1)
        names.append(nm)
        rows = [(sh.get('h') or [], 1)] + [(r, 0) for r in sh.get('r') or []] + ([(sh['f'], 2)] if sh.get('f') else [])
        widths = [8] * max([len(r) for r, _ in rows] + [1])
        body = []
        for ri, (r, st_) in enumerate(rows, 1):
            cells = []
            for ci, v in enumerate(r):
                if v is None or v == '': 
                    if st_: cells.append('<c r="%s%d" s="%d"/>' % (col(ci), ri, st_))
                    continue
                widths[ci] = min(45, max(widths[ci], len(str(v)) + 2))
                ref = '%s%d' % (col(ci), ri)
                if isinstance(v, (int, float)) and not isinstance(v, bool): cells.append('<c r="%s" s="%d"><v>%s</v></c>' % (ref, st_, repr(v)))
                else: cells.append('<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, st_, xesc(clean(v))))
            body.append('<row r="%d">%s</row>' % (ri, ''.join(cells)))
        parts['xl/worksheets/sheet%d.xml' % (i + 1)] = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="%s"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>%s</cols><sheetData>%s</sheetData></worksheet>'
            % (M, ''.join('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (k + 1, k + 1, w) for k, w in enumerate(widths)), ''.join(body)))
    parts['xl/workbook.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="%s" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>%s</sheets></workbook>' % (M, ''.join('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (xesc(n, {'"': '&quot;'}), i + 1, i + 1) for i, n in enumerate(names)))
    parts['xl/_rels/workbook.xml.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">%s<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % ''.join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(len(sheets)))
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, 'w', zipfile.ZIP_DEFLATED) as z:
        for k, v in parts.items(): z.writestr(k, v)
    return bio.getvalue()


def read_xlsx(b):
    """Read the first sheet of an .xlsx into a list of rows (strings)."""
    z = zipfile.ZipFile(io.BytesIO(b)); M = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    ss = []
    if 'xl/sharedStrings.xml' in z.namelist():
        ss = [''.join(t.text or '' for t in si.iter(M + 't')) for si in ET.fromstring(z.read('xl/sharedStrings.xml')).iter(M + 'si')]
    sheet = sorted(n for n in z.namelist() if n.startswith('xl/worksheets/sheet'))[0]
    rows = []
    for row in ET.fromstring(z.read(sheet)).iter(M + 'row'):
        vals = {}
        for c in row.iter(M + 'c'):
            idx = 0
            for ch in re.match(r'[A-Z]+', c.get('r')).group(): idx = idx * 26 + ord(ch) - 64
            t, v = c.get('t'), c.find(M + 'v')
            if t == 's' and v is not None: val = ss[int(v.text)]
            elif t == 'inlineStr': val = ''.join(x.text or '' for x in c.iter(M + 't'))
            elif v is not None:
                val = v.text or ''
                if re.fullmatch(r'-?\d+\.0+', val): val = val.split('.')[0]
                elif re.fullmatch(r'-?[\d.]+[Ee][+-]?\d+', val):
                    from decimal import Decimal
                    val = format(Decimal(val), 'f').rstrip('0').rstrip('.') if '.' in format(Decimal(val), 'f') else format(Decimal(val), 'f')
            else: val = ''
            vals[idx - 1] = val
        if vals: rows.append([vals.get(i, '') for i in range(max(vals) + 1)])
    return rows


def bootstrap():
    if kv_get('core') is None:
        seed = os.path.join(HERE, 'seed.json')
        if not os.path.exists(seed): raise SystemExit('seed.json not found next to server.py')
        kv_set('core', json.load(open(seed, encoding='utf-8'))); kv_set('rev', 1)
        print('\n  NOTE: seed.json holds employee PAN / bank / UAN numbers. It is only needed for this first start - delete it now and keep a copy somewhere safe.\n', flush=True)
    if not db.execute('SELECT 1 FROM users').fetchone():
        pw = secrets.token_urlsafe(9)
        mkuser('admin', 'Administrator', pw, 'admin'); audit('system', 'first run', 'admin user created')
        print('\n  FIRST RUN - sign in with   username: admin   password: %s\n  (change it after signing in; this is shown only once)\n' % pw, flush=True)
    db.commit()


def cur_user(h):
    c = SimpleCookie(h.headers.get('Cookie', ''))
    if 'sid' not in c: return None
    r = db.execute('SELECT u,exp FROM sess WHERE t=?', (hashlib.sha256(c['sid'].value.encode()).hexdigest(),)).fetchone()
    if not r or r['exp'] < time.time(): return None
    u = db.execute('SELECT u,name,role,branch,active,emp,must FROM users WHERE u=?', (r['u'],)).fetchone()
    return dict(u) if u and u['active'] else None


def need(u, roles=None):
    if not u: raise Err(401, 'Please sign in')
    if roles and u['role'] not in roles: raise Err(403, 'You do not have permission for this')
    return u


def emp_of(c): return next((x for x in kv_get('core')['emps'] if x['c'] == c), None)
def u_emp(c): return [r['u'] for r in db.execute('SELECT u FROM users WHERE emp=? AND active=1', (c,))]
def u_branch(b): return [r['u'] for r in db.execute("SELECT u FROM users WHERE role='branch' AND branch=? AND active=1", (b,))]
def u_roles(roles): return [r['u'] for r in db.execute('SELECT u FROM users WHERE role IN (%s) AND active=1' % ','.join('?' * len(roles)), tuple(roles))]


def notify(users, msg):
    users = [x for x in dict.fromkeys(users) if x]
    for x in users: db.execute('INSERT INTO notif(u,msg,ts) VALUES(?,?,?)', (x, str(msg)[:300], now()))
    if WEBHOOK and users:                              # optional outside delivery, sent in the background; failures are ignored
        phones = {e['c']: e.get('phone', '') for e in kv_get('core')['emps']}
        out = []
        for x in users:
            r = db.execute('SELECT emp FROM users WHERE u=?', (x,)).fetchone()
            out.append(dict(to=x, emp=(r['emp'] if r else '') or '', phone=phones.get((r['emp'] if r else '') or '', ''), message=str(msg)[:300]))
        def go():
            import urllib.request
            for o in out:
                try: urllib.request.urlopen(urllib.request.Request(WEBHOOK, json.dumps(o).encode(), {'Content-Type': 'application/json'}), timeout=5).read()
                except Exception: pass
        threading.Thread(target=go, daemon=True).start()


def movs_all(codes=None):
    return [dict(json.loads(r['j']), id=r['id'], c=r['c'], kind=r['kind'], eff=r['eff'], ref=r['ref'], ts=r['ts']) for r in db.execute('SELECT * FROM movs ORDER BY id DESC') if codes is None or r['c'] in codes]


def inct_all(m, codes=None):
    return [dict(c=r['c'], tgt=r['tgt'], ach=r['ach']) for r in db.execute('SELECT * FROM inct WHERE m=?', (m,)) if codes is None or r['c'] in codes]


def ly_start(core):
    t, m = datetime.date.fromisoformat(today()), int(core['set'].get('lyEnd', 12) or 12)
    return datetime.date(t.year if (m == 12 or t.month > m) else t.year - 1, 1 if m == 12 else m + 1, 1).isoformat()


def lvu_all(core):
    out = {}
    for r in db.execute("SELECT c, COALESCE(lt,'CL') AS lt, SUM(d) AS n FROM lr WHERE s IN ('Pending','Approved') AND f>=? GROUP BY c, COALESCE(lt,'CL')", (ly_start(core),)):
        out.setdefault(r['c'], {})[r['lt']] = r['n']
    return out


def chk_quota(core, c, lt, days):
    q = float(core['set'].get('q' + lt, 0) or 0)
    if q <= 0: return
    used = lvu_all(core).get(c, {}).get(lt, 0)
    if used + days > q + 1e-9: raise Err(400, '%s leave: %g of %g day(s) already used or requested this leave year, so %g more day(s) cannot be added' % (lt, used, q, days))


def decl_all(codes=None):
    files = {}
    for r in db.execute('SELECT id,c,fy,name,mime,length(data) AS n FROM proof ORDER BY id'):
        files.setdefault((r['c'], r['fy']), []).append(dict(id=r['id'], name=r['name'], mime=r['mime'], n=r['n']))
    return [dict(json.loads(r['j']), c=r['c'], fy=r['fy'], st=r['st'], note=r['note'] or '', ts=r['ts'], files=files.get((r['c'], r['fy']), []))
            for r in db.execute('SELECT * FROM decl') if codes is None or r['c'] in codes]


def state_for(u):
    core, rev = kv_get('core'), kv_get('rev')
    cy = core['cyc']
    rows = db.execute('SELECT c,d,s FROM att WHERE d>=? AND d<=?', (cy['start'], cy['end'])).fetchall()
    lrs = [dict(id=r['id'], c=r['c'], f=r['f'], to=r['t2'], d=r['d'], r=r['r'], s=r['s'], lt=r['lt'] or 'CL', hs=r['hs'] or '') for r in db.execute('SELECT * FROM lr ORDER BY id')]
    ars = [dict(id=r['id'], c=r['c'], d=r['d'], s=r['s'], st=r['st'], ts=r['ts'] or '', apb=r['apby'] or '', apt=r['apts'] or '', ss=r['sess'] or '', lt=r['lt'] or '', wh=r['wh'] or '', pu=r['pu'] or '', geo=(r['lat'] + ',' + r['lng'] + ',' + (r['acc'] or '')) if r['lat'] else '', ph=bool(r['hp'])) for r in db.execute("SELECT id,c,d,s,st,ts,apby,apts,sess,lt,wh,pu,lat,lng,acc,(photo IS NOT NULL AND photo!='') AS hp FROM ar WHERE d>=? AND d<=? ORDER BY id", (cy['start'], cy['end']))]
    if u['role'] == 'employee':
        e = next((x for x in core['emps'] if x['c'] == u['emp']), None)
        if not e: raise Err(403, 'Your employee record was not found. Please contact HR.')
        att = {}
        for r in rows:
            if r['c'] == e['c']: att.setdefault(r['c'], {})[r['d']] = r['s']
        paid = {(r['m'], r['b']): r['d'] for r in db.execute('SELECT m,b,d FROM paid')}
        hist = [h for h in (dict(json.loads(r['j']), m=r['m']) for r in db.execute('SELECT m,j FROM pay WHERE c=? ORDER BY rowid', (e['c'],))) if (h['m'], h.get('b') or e['b']) in paid]   # a payslip is visible only after the salary is paid
        paid_list = [dict(m=h['m'], b=h.get('b') or e['b'], d=paid[(h['m'], h.get('b') or e['b'])]) for h in hist]
        return dict(emps=[e], br={e['b']: core['br'].get(e['b'], True)}, cyc=cy, bal={e['c']: core['bal'].get(e['c'], 0)}, hist=hist, enc=[], ye={}, set=core['set'],
                    co={k: (core.get('co') or {}).get(k, '') for k in ('name', 'addr', 'pf')}, paid=paid_list, hol=[h for h in core.get('hol', []) if not h.get('b') or h['b'] == e['b']], des=[], att=att, lr=[x for x in lrs if x['c'] == e['c']], ar=[x for x in ars if x['c'] == e['c']], decl=decl_all({e['c']}), lvu={e['c']: lvu_all(core).get(e['c'], {})}, movs=movs_all({e['c']}), inct=inct_all(core['cyc']['label'], {e['c']}), rev=rev)
    if u['role'] in FULL:
        att = {}
        for r in rows: att.setdefault(r['c'], {})[r['d']] = r['s']
        return dict(core, att=att, lr=lrs, ar=ars, paid=[dict(r) for r in db.execute('SELECT m,b,d FROM paid')], decl=decl_all(), lvu=lvu_all(core), movs=movs_all(), inct=inct_all(core['cyc']['label']), fnf=[dict(json.loads(r['j']), c=r['c'], ts=r['ts']) for r in db.execute('SELECT * FROM fnf')], rev=rev)
    b = u['branch']                                   # branch users: own branch, no salary data
    emps = [{k: e[k] for k in ('c', 'n', 'b', 'd', 'doj')} for e in core['emps'] if e['b'] == b]
    codes = {e['c'] for e in emps}
    att = {}
    for r in rows:
        if r['c'] in codes: att.setdefault(r['c'], {})[r['d']] = r['s']
    s = core['set']
    return dict(emps=emps, br={b: True}, cyc=cy, bal={c: core['bal'].get(c, 0) for c in codes}, hist=[], enc=[], ye={},
                set={k: s.get(k) for k in ('acc', 'absLv', 'days', 'lockDays', 'autoSun', 'wait', 'cap', 'unAbs')}, co={}, hol=[h for h in core.get('hol', []) if not h.get('b') or h['b'] == b], des=[], att=att, lr=[x for x in lrs if x['c'] in codes], ar=[x for x in ars if x['c'] in codes], rev=rev)


def valid_date(d):
    try: return datetime.date.fromisoformat(d).isoformat() == d
    except Exception: return False


def handle(h, m, p, body, ip):
    me = cur_user(h)
    if p == 'login' and m == 'POST':
        u, pw = str(body.get('u', '')).strip().lower(), str(body.get('p', ''))
        k, t = (ip, u), time.time()
        f = [x for x in FAILS.get(k, []) if t - x < 300]
        if len(f) >= 5: raise Err(429, 'Too many attempts. Please wait a few minutes.')
        r = db.execute('SELECT * FROM users WHERE u=?', (u,)).fetchone()
        ok = hmac.compare_digest(hpw(pw, r['salt'] if r else '00' * 16), r['h'] if r else 'x' * 64) and r and r['active']
        if not ok:
            FAILS[k] = f + [t]; audit(u or '?', 'login failed', ip); db.commit()
            raise Err(401, 'Wrong username or password')
        FAILS.pop(k, None); tok = secrets.token_urlsafe(32)
        db.execute('DELETE FROM sess WHERE exp<?', (t,))
        db.execute('INSERT INTO sess VALUES(?,?,?)', (hashlib.sha256(tok.encode()).hexdigest(), u, t + 12 * 3600))
        audit(u, 'login', ip); db.commit()
        return dict(user=dict(u=u, name=r['name'], role=r['role'], branch=r['branch'], emp=r['emp'] or '', must=r['must'] or 0), _cookie=tok)
    if p == 'me': return dict(user=need(me))
    if p == 'logout' and m == 'POST':
        c = SimpleCookie(h.headers.get('Cookie', ''))
        if 'sid' in c: db.execute('DELETE FROM sess WHERE t=?', (hashlib.sha256(c['sid'].value.encode()).hexdigest(),))
        db.commit(); return dict(ok=1, _cookie='')
    u = need(me)
    if u.get('must') and p not in ('me', 'logout', 'password'): raise Err(403, 'Please set a new password first')
    if p == 'state' and m == 'GET': return state_for(u)
    if p == 'state' and m == 'POST':
        need(u, WCORE)
        if body.get('rev') != kv_get('rev'): raise Err(409, 'Someone else changed the data. The latest data will be loaded.')
        new, old = body.get('core') or {}, kv_get('core')
        if not isinstance(new.get('emps'), list) or not new['emps'] or not isinstance(new.get('set'), dict): raise Err(400, 'Invalid data')
        codes = [str(e.get('c')) for e in new['emps']]
        if len(set(codes)) != len(codes): raise Err(400, 'Duplicate employee codes')
        core = {k: new.get(k, old.get(k)) for k in CORE_KEYS if k in new or k in old}
        om = {e['c']: json.dumps(e, sort_keys=True) for e in old['emps']}
        ch = sum(1 for e in core['emps'] if om.get(e['c']) != json.dumps(e, sort_keys=True))
        kv_set('core', core); rev = kv_get('rev') + 1; kv_set('rev', rev)
        audit(u['u'], 'data saved', '%d employee record(s) changed/added, %d removed, settings %s' % (ch, len(set(om) - set(codes)), 'changed' if old['set'] != core['set'] else 'unchanged'))
        db.commit(); return dict(rev=rev)
    if p == 'att' and m == 'POST':
        ch, core = body.get('changes'), kv_get('core')
        if not isinstance(ch, list) or len(ch) > 6000: raise Err(400, 'Invalid request')
        cy, emps, t = core['cyc'], {e['c']: e for e in core['emps']}, today()
        lock = int(core['set'].get('lockDays', 3))
        lo = (datetime.date.fromisoformat(t) - datetime.timedelta(days=lock)).isoformat()
        for x in ch:
            c, d, s = x.get('c'), x.get('d'), x.get('s') or ''
            if c not in emps: raise Err(400, 'Unknown employee')
            if s not in STATUS and s != '': raise Err(400, 'Invalid status')
            if not (isinstance(d, str) and valid_date(d) and cy['start'] <= d <= cy['end']): raise Err(403, 'That date is outside the current pay cycle')
            if u['role'] in WATT: continue
            if u['role'] != 'branch': raise Err(403, 'You do not have permission for this')
            if emps[c]['b'] != u['branch']: raise Err(403, 'You can only update your own branch')
            if d > t or d < lo: raise Err(403, 'Branches can update attendance only for the last %d days (HR can correct older dates)' % lock)
        det = []
        for x in ch:
            c, d, s = x['c'], x['d'], x.get('s') or ''
            r = db.execute('SELECT s FROM att WHERE c=? AND d=?', (c, d)).fetchone(); old = r['s'] if r else ''
            if old == s: continue
            if s: db.execute('INSERT OR REPLACE INTO att VALUES(?,?,?)', (c, d, s))
            else: db.execute('DELETE FROM att WHERE c=? AND d=?', (c, d))
            det.append('%s %s: %s to %s' % (c, d, old or 'blank', s or 'blank'))
        if det: audit(u['u'], 'attendance', '%d change(s). %s' % (len(det), '; '.join(det[:6]) + (' ...' if len(det) > 6 else '')))
        db.commit(); return dict(ok=1, changed=len(det))
    if p == 'lr' and m == 'POST':
        core = kv_get('core'); e = next((x for x in core['emps'] if x['c'] == body.get('c')), None)
        f, to = body.get('f'), body.get('to')
        if not e: raise Err(400, 'Unknown employee')
        if u['role'] == 'branch' and e['b'] != u['branch']: raise Err(403, 'You can only update your own branch')
        if u['role'] == 'employee' and e['c'] != u['emp']: raise Err(403, 'You can only apply for your own leave')
        if u['role'] not in WATT and u['role'] not in ('branch', 'employee'): raise Err(403, 'You do not have permission for this')
        if not (valid_date(f or '') and valid_date(to or '') and f <= to): raise Err(400, 'Please choose valid dates')
        lt, hs = str(body.get('lt') or 'CL').upper(), str(body.get('h') or '')
        if lt not in LTYPES: raise Err(400, 'Please choose a leave type: CL, SL or EL')
        if hs and hs not in SESS: raise Err(400, 'Half-day leave must be Morning or Afternoon')
        if hs and f != to: raise Err(400, 'A half-day leave is for a single date')
        days = 0.5 if hs else (datetime.date.fromisoformat(to) - datetime.date.fromisoformat(f)).days + 1
        chk_quota(core, e['c'], lt, days)
        db.execute('INSERT INTO lr(c,f,t2,d,r,s,by,ts,lt,hs) VALUES(?,?,?,?,?,?,?,?,?,?)', (e['c'], f, to, days, str(body.get('r', ''))[:300], 'Pending', u['u'], now(), lt, hs))
        notify(u_branch(e['b']) + u_roles(('hr', 'admin')), '%s applied for %s leave (%s to %s) - waiting for approval' % (e['n'], lt, f, to))
        audit(u['u'], 'leave request', '%s %s to %s (%s%s)' % (e['c'], f, to, lt, ', half-day ' + hs if hs else '')); db.commit(); return dict(ok=1)
    if p == 'lr/act' and m == 'POST':
        need(u, WATT | {'branch'}); r = db.execute('SELECT * FROM lr WHERE id=?', (body.get('id'),)).fetchone(); s = body.get('s')
        if not r or r['s'] != 'Pending' or s not in ('Approved', 'Rejected'): raise Err(400, 'This request cannot be changed')
        if u['role'] == 'branch':
            e = next((x for x in kv_get('core')['emps'] if x['c'] == r['c']), None)
            if not e or e['b'] != u['branch']: raise Err(403, 'You can only approve leave for your own branch')
        db.execute('UPDATE lr SET s=? WHERE id=?', (s, r['id']))
        if s == 'Approved':
            d0 = datetime.date.fromisoformat(r['f'])
            if r['hs']: db.execute('INSERT OR REPLACE INTO att VALUES(?,?,?)', (r['c'], d0.isoformat(), 'HD'))      # half-day leave
            else:
                for i in range(int(r['d'])): db.execute('INSERT OR REPLACE INTO att VALUES(?,?,?)', (r['c'], (d0 + datetime.timedelta(days=i)).isoformat(), 'L'))
        notify(u_emp(r['c']), 'Your %s leave (%s to %s) was %s' % (r['lt'] or 'CL', r['f'], r['t2'], s.lower()))
        audit(u['u'], 'leave ' + s.lower(), '%s %s to %s' % (r['c'], r['f'], r['t2'])); db.commit(); return dict(ok=1)
    if p == 'attreq' and m == 'POST':
        need(u, {'employee'}); core = kv_get('core'); cy, t = core['cyc'], today()
        c, d, s = u['emp'], body.get('d'), body.get('s')
        if s not in ('P', 'HD', 'OD'): raise Err(400, 'You can mark Present, Half-day leave or On duty. Apply for full-day leave from the Leave page.')
        ss = lt = wh = pu = ''
        if s == 'HD':
            ss, lt = str(body.get('ss') or ''), str(body.get('lt') or '').upper()
            if ss not in SESS: raise Err(400, 'Please choose Morning or Afternoon for the half-day leave')
            if lt not in LTYPES: raise Err(400, 'Please choose a leave type: CL, SL or EL')
            chk_quota(core, c, lt, 0.5)
        if s == 'OD':
            wh, pu = clean(body.get('wh') or '').strip()[:100], clean(body.get('pu') or '').strip()[:200]
            if not wh or not pu: raise Err(400, 'For On duty, please enter where you are going and the purpose')
        lat = lng = acc = photo = ''
        if body.get('lat') not in (None, ''):
            try:
                la, lo_, ac = float(body.get('lat')), float(body.get('lng')), float(body.get('acc') or 0)
                if not (-90 <= la <= 90 and -180 <= lo_ <= 180): raise ValueError
                lat, lng, acc = '%.6f' % la, '%.6f' % lo_, '%d' % min(max(ac, 0), 99999)
            except (TypeError, ValueError): raise Err(400, 'The location was not valid. Please capture it again.')
        ph = body.get('photo')
        if ph:
            if not (isinstance(ph, str) and len(ph) <= 400000 and re.fullmatch(r'data:image/jpeg;base64,[A-Za-z0-9+/=]+', ph)): raise Err(400, 'The selfie was not valid. Please take it again.')
            photo = ph
        if float(core['set'].get('chk', 0) or 0) and s in ('P', 'OD') and not (lat and photo):
            raise Err(400, 'Your company needs a selfie and your location to mark attendance. Please capture both.')
        lock = int(core['set'].get('lockDays', 3)); lo = (datetime.date.fromisoformat(t) - datetime.timedelta(days=lock)).isoformat()
        if not (isinstance(d, str) and valid_date(d) and cy['start'] <= d <= cy['end']): raise Err(403, 'That date is outside the current pay cycle')
        if d > t or d < lo: raise Err(403, 'You can mark attendance only for today and the last %d days' % lock)
        if db.execute('SELECT 1 FROM att WHERE c=? AND d=?', (c, d)).fetchone(): raise Err(400, 'Your branch has already marked this day')
        if db.execute("SELECT 1 FROM ar WHERE c=? AND d=? AND st='Pending'", (c, d)).fetchone(): raise Err(400, 'You already have a request waiting for this day')
        db.execute('INSERT INTO ar(c,d,s,st,by,ts,sess,lt,wh,pu,lat,lng,acc,photo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (c, d, s, 'Pending', u['u'], now(), ss, lt, wh, pu, lat, lng, acc, photo))
        _e = emp_of(c); notify(u_branch(_e['b']) if _e else [], '%s marked %s for %s - waiting for your approval' % (_e['n'] if _e else c, {'P': 'Present', 'HD': 'Half-day leave', 'OD': 'On duty'}.get(s, s), d))
        audit(u['u'], 'attendance requested', '%s %s as %s%s' % (c, d, s, ' (%s, %s)' % (ss, lt) if s == 'HD' else ' at %s: %s' % (wh, pu) if s == 'OD' else '')); db.commit(); return dict(ok=1)
    if p == 'attreq/act' and m == 'POST':
        need(u, {'admin', 'hr', 'branch'}); ids, a = body.get('ids') or [], body.get('a')
        if a not in ('Approved', 'Rejected') or not isinstance(ids, list) or not ids or len(ids) > 2000: raise Err(400, 'Invalid request')
        emps, n = {e['c']: e for e in kv_get('core')['emps']}, 0
        for i in ids:
            r = db.execute('SELECT * FROM ar WHERE id=?', (i,)).fetchone()
            if not r or r['st'] != 'Pending': continue
            if u['role'] == 'branch' and emps.get(r['c'], {}).get('b') != u['branch']: raise Err(403, 'You can only approve your own branch')
            st_ = a
            if a == 'Approved':
                if db.execute('SELECT 1 FROM att WHERE c=? AND d=?', (r['c'], r['d'])).fetchone(): st_ = 'Superseded'
                else:
                    db.execute('INSERT INTO att VALUES(?,?,?)', (r['c'], r['d'], r['s']))
                    if r['s'] == 'HD': db.execute('INSERT INTO lr(c,f,t2,d,r,s,by,ts,lt,hs) VALUES(?,?,?,?,?,?,?,?,?,?)', (r['c'], r['d'], r['d'], 0.5, 'Half-day marked by employee', 'Approved', u['u'], now(), r['lt'] or 'CL', r['sess'] or ''))
            db.execute('UPDATE ar SET st=?, apby=?, apts=? WHERE id=?', (st_, u['u'], now(), r['id'])); n += 1
            if st_ in ('Approved', 'Rejected'): notify(u_emp(r['c']), 'Your attendance for %s was %s' % (r['d'], st_.lower()))
        audit(u['u'], 'attendance request ' + a.lower(), '%d request(s)' % n); db.commit(); return dict(ok=1, changed=n)
    if p == 'arphoto' and m == 'POST':                # check-in selfie for one attendance request
        need(u, FULL | {'branch'}); r = db.execute('SELECT c,photo FROM ar WHERE id=?', (body.get('id'),)).fetchone()
        if not r or not r['photo']: raise Err(404, 'No selfie for this entry')
        if u['role'] == 'branch':
            e = next((x for x in kv_get('core')['emps'] if x['c'] == r['c']), None)
            if not e or e['b'] != u['branch']: raise Err(403, 'You can only view your own branch')
        return dict(photo=r['photo'])
    if p == 'decl' and m == 'POST':                   # employee: submit / update the investment declaration
        need(u, {'employee'}); fy = int(body.get('fy') or 0); d = body.get('d') or {}
        if not (2020 <= fy <= 2100) or not isinstance(d, dict): raise Err(400, 'Invalid declaration')
        num = lambda k: max(0.0, min(float(d.get(k) or 0), 1e8))
        out = dict(reg='old' if d.get('reg') == 'old' else 'new', metro=1 if d.get('metro') in (1, '1', True) else 0, parsr=1 if d.get('parsr') in (1, '1', True) else 0,
                   lname=clean(d.get('lname') or '')[:100], lpan=clean(d.get('lpan') or '').upper()[:10], olabel=clean(d.get('olabel') or '')[:100])
        for k in ('rent', 'lic', 'ppf', 'elss', 'tuition', 'hlp', 'nsc', 'o80c', 'nps', 'd80s', 'd80p', 'hli', 'e80', 'don', 'other'):
            try: out[k] = num(k)
            except (TypeError, ValueError): raise Err(400, 'Please enter numbers only')
        db.execute('INSERT OR REPLACE INTO decl VALUES(?,?,?,?,?,?)', (u['emp'], fy, json.dumps(out), 'Pending', '', now()))
        _e = emp_of(u['emp']); notify(u_roles(('hr', 'admin')), '%s submitted a tax declaration for FY %d - waiting for review' % (_e['n'] if _e else u['emp'], fy))
        audit(u['u'], 'declaration submitted', '%s FY %d (%s regime)' % (u['emp'], fy, out['reg'])); db.commit(); return dict(ok=1)
    if p == 'decl/act' and m == 'POST':
        need(u, WCORE); a = body.get('a')
        if a not in ('Approved', 'Rejected'): raise Err(400, 'Invalid request')
        r = db.execute('SELECT 1 FROM decl WHERE c=? AND fy=?', (body.get('c'), body.get('fy'))).fetchone()
        if not r: raise Err(404, 'Declaration not found')
        db.execute('UPDATE decl SET st=?, note=? WHERE c=? AND fy=?', (a, clean(body.get('note') or '')[:300], body.get('c'), body.get('fy')))
        notify(u_emp(str(body.get('c'))), 'Your tax declaration for FY %s was %s%s' % (body.get('fy'), a.lower(), (' - ' + clean(body.get('note') or '')[:120]) if body.get('note') else ''))
        audit(u['u'], 'declaration ' + a.lower(), '%s FY %s' % (body.get('c'), body.get('fy'))); db.commit(); return dict(ok=1)
    if p == 'proof' and m == 'POST':                  # employee uploads a proof document (PDF / JPG / PNG, up to 1.5 MB)
        need(u, {'employee'}); fy = int(body.get('fy') or 0); mime = body.get('mime')
        if mime not in ('application/pdf', 'image/jpeg', 'image/png'): raise Err(400, 'Only PDF, JPG or PNG files are allowed')
        try: data = base64.b64decode(body.get('b64') or '', validate=True)
        except Exception: raise Err(400, 'The file could not be read')
        if not data or len(data) > 1_500_000: raise Err(400, 'Each file must be under 1.5 MB')
        if db.execute('SELECT COUNT(*) FROM proof WHERE c=? AND fy=?', (u['emp'], fy)).fetchone()[0] >= 10: raise Err(400, 'You can upload up to 10 documents')
        db.execute('INSERT INTO proof(c,fy,name,mime,data,ts) VALUES(?,?,?,?,?,?)', (u['emp'], fy, clean(body.get('name') or 'document')[:100], mime, data, now()))
        audit(u['u'], 'proof uploaded', '%s FY %d' % (u['emp'], fy)); db.commit(); return dict(ok=1)
    if p == 'proof/del' and m == 'POST':
        need(u, {'employee'}); db.execute('DELETE FROM proof WHERE id=? AND c=?', (body.get('id'), u['emp'])); db.commit(); return dict(ok=1)
    if p == 'proofget' and m == 'POST':
        r = db.execute('SELECT * FROM proof WHERE id=?', (body.get('id'),)).fetchone()
        if not r or (u['role'] == 'employee' and r['c'] != u['emp']) or (u['role'] != 'employee' and u['role'] not in WCORE): raise Err(404, 'Not found')
        return dict(name=r['name'], mime=r['mime'], b64=base64.b64encode(r['data']).decode())
    if p == 'fnf' and m == 'POST':                    # save a full & final settlement
        need(u, WCORE); c, d = str(body.get('c') or ''), body.get('d')
        if not isinstance(d, dict) or not any(e['c'] == c for e in kv_get('core')['emps']): raise Err(400, 'Invalid settlement')
        j = json.dumps(d)
        if len(j) > 30000: raise Err(400, 'Too much data')
        db.execute('INSERT OR REPLACE INTO fnf VALUES(?,?,?,?)', (c, j, now(), u['u']))
        audit(u['u'], 'full & final saved', '%s last day %s' % (c, str(d.get('lwd', ''))[:10])); db.commit(); return dict(ok=1)
    if p == 'notifs' and m == 'GET':                  # the bell
        return dict(rows=[dict(r) for r in db.execute('SELECT id,msg,ts,rd FROM notif WHERE u=? ORDER BY id DESC LIMIT 40', (u['u'],))],
                    unread=db.execute('SELECT COUNT(*) FROM notif WHERE u=? AND rd=0', (u['u'],)).fetchone()[0])
    if p == 'notifs/read' and m == 'POST':
        if body.get('id'): db.execute('UPDATE notif SET rd=1 WHERE u=? AND id=?', (u['u'], body.get('id')))
        else: db.execute('UPDATE notif SET rd=1 WHERE u=?', (u['u'],))
        db.commit(); return dict(ok=1)
    if p == 'move' and m == 'POST':                   # salary revision / promotion / transfer / confirmation record (for the letter)
        need(u, WCORE); c, kind, eff = str(body.get('c') or ''), body.get('kind'), str(body.get('eff') or '')[:10]
        if kind not in ('Increment', 'Promotion', 'Transfer', 'Confirmation') or not emp_of(c): raise Err(400, 'Invalid request')
        try: datetime.date.fromisoformat(eff)
        except ValueError: raise Err(400, 'Please enter a valid effective date')
        d = body.get('d') if isinstance(body.get('d'), dict) else {}
        keep = {k: (str(d.get(k, ''))[:200] if k in ('od', 'nd', 'ob', 'nb', 'note') else float(d.get(k) or 0)) for k in ('od', 'nd', 'ob', 'nb', 'ot', 'nt', 'note')}
        rid = db.execute('INSERT INTO movs(c,kind,eff,j,ref,by,ts) VALUES(?,?,?,?,?,?,?)', (c, kind, eff, json.dumps(keep), '', u['u'], now())).lastrowid
        ref = 'HR/%s/%04d' % (eff[:4], rid); db.execute('UPDATE movs SET ref=? WHERE id=?', (ref, rid))
        notify(u_emp(c), 'A %s letter (%s) has been issued to you, effective %s' % (kind.lower(), ref, eff))
        audit(u['u'], kind.lower() + ' recorded', '%s effective %s (%s)' % (c, eff, ref)); db.commit(); return dict(ok=1, ref=ref, id=rid)
    if p == 'inct' and m == 'POST':                   # monthly targets and achievements
        need(u, WCORE); mm, rows = str(body.get('m') or '')[:20], body.get('rows')
        if not mm or not isinstance(rows, list) or len(rows) > 5000: raise Err(400, 'Invalid request')
        for x in rows:
            try: db.execute('INSERT OR REPLACE INTO inct VALUES(?,?,?,?)', (str(x['c']), mm, max(0.0, min(float(x.get('tgt') or 0), 1e10)), max(0.0, min(float(x.get('ach') or 0), 1e10))))
            except (TypeError, ValueError, KeyError): raise Err(400, 'Please enter numbers only')
        audit(u['u'], 'targets saved', '%s: %d employees' % (mm, len(rows))); db.commit(); return dict(ok=1)
    if p == 'paid' and m == 'POST':                    # mark a month's salary as paid for a branch (employees then see the payslip)
        need(u, WCORE); mm, b = str(body.get('m') or ''), str(body.get('b') or '')
        if not db.execute('SELECT 1 FROM pay WHERE m=? LIMIT 1', (mm,)).fetchone(): raise Err(400, 'That month has not been closed')
        if body.get('undo'):
            db.execute('DELETE FROM paid WHERE m=? AND b=?', (mm, b)); audit(u['u'], 'salary paid status removed', '%s %s' % (mm, b)); db.commit(); return dict(ok=1)
        d = str(body.get('d') or '')
        if not valid_date(d) or d > today(): raise Err(400, 'Choose a valid payment date (not in the future)')
        db.execute('INSERT OR REPLACE INTO paid VALUES(?,?,?,?,?)', (mm, b, d, u['u'], now()))
        for r in db.execute('SELECT c,j FROM pay WHERE m=?', (mm,)):
            if (json.loads(r['j']).get('b') or (emp_of(r['c']) or {}).get('b')) == b: notify(u_emp(r['c']), 'Your %s salary was paid on %s. Your payslip is now available.' % (mm, d))
        audit(u['u'], 'salary marked as paid', '%s %s on %s' % (mm, b, d)); db.commit(); return dict(ok=1)
    if p == 'attrange' and m == 'POST':                # attendance for any dates (up to one year), for the date-to-date report
        need(u, FULL); f, t = str(body.get('f') or ''), str(body.get('t') or '')
        if not (valid_date(f) and valid_date(t)) or f > t or (datetime.date.fromisoformat(t) - datetime.date.fromisoformat(f)).days > 366: raise Err(400, 'Choose dates up to one year apart')
        return dict(rows=[[r['c'], r['d'], r['s']] for r in db.execute('SELECT c,d,s FROM att WHERE d>=? AND d<=?', (f, t))])
    if p == 'payall' and m == 'POST':                 # every closed month of every employee (year-to-date reports)
        need(u, FULL)
        return dict(rows=[dict(json.loads(r['j']), m=r['m'], c=r['c']) for r in db.execute('SELECT c,m,j FROM pay ORDER BY rowid')])
    if p == 'payhist' and m == 'POST':                # earlier months of one employee (for the income-tax worksheet on a payslip)
        need(u, WCORE)
        return dict(rows=[dict(json.loads(r['j']), m=r['m']) for r in db.execute('SELECT m,j FROM pay WHERE c=? ORDER BY rowid', (str(body.get('c', '')),))])
    if p == 'payslips' and m == 'POST':
        need(u, WCORE); rows = body.get('rows')
        if not isinstance(rows, list) or not body.get('m'): raise Err(400, 'Invalid request')
        for x in rows: db.execute('INSERT OR REPLACE INTO pay VALUES(?,?,?)', (str(x['c']), str(body['m']), json.dumps({k: v for k, v in x.items() if k != 'c'})))
        audit(u['u'], 'payslips stored', '%s: %d employees' % (body['m'], len(rows))); db.commit(); return dict(ok=1)
    if p == 'xlsx' and m == 'POST':
        sh = body.get('sheets')
        if not isinstance(sh, list) or not sh or sum(len(x.get('r') or []) for x in sh) > 60000: raise Err(400, 'Invalid request')
        return ('bin', make_xlsx(sh), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    if p == 'xlsx/read' and m == 'POST':
        need(u, WCORE)
        try: return dict(rows=read_xlsx(base64.b64decode(body.get('b64', ''))))
        except Exception: raise Err(400, 'This does not look like a valid .xlsx file (CSV is also accepted)')
    if p == 'password' and m == 'POST':
        r = db.execute('SELECT * FROM users WHERE u=?', (u['u'],)).fetchone(); n = str(body.get('n', ''))
        if not hmac.compare_digest(hpw(str(body.get('o', '')), r['salt']), r['h']): raise Err(403, 'Current password is wrong')
        if len(n) < 8: raise Err(400, 'The new password must have at least 8 characters')
        salt = secrets.token_hex(16); db.execute('UPDATE users SET salt=?,h=?,must=0 WHERE u=?', (salt, hpw(n, salt), u['u']))
        audit(u['u'], 'password changed'); db.commit(); return dict(ok=1)
    if p == 'audit' and m == 'GET':
        need(u, {'admin', 'hr'})
        return dict(rows=[[r['ts'], r['u'], r['a'], r['x']] for r in db.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 300')])
    if p.startswith('users'):
        need(u, {'admin'})
        if p == 'users' and m == 'GET':
            return dict(users=[dict(r) for r in db.execute('SELECT u,name,role,branch,active,emp FROM users ORDER BY role,u')])
        if p == 'users' and m == 'POST':
            n, role, br = str(body.get('u', '')).strip().lower(), body.get('role'), body.get('branch', '')
            if not re.fullmatch(r'[a-z0-9._-]{3,30}', n): raise Err(400, 'Username: 3-30 letters, numbers, . _ -')
            if role not in ROLES: raise Err(400, 'Invalid role')
            if role == 'branch' and br not in kv_get('core')['br']: raise Err(400, 'Choose a branch')
            emp = str(body.get('emp', '')).strip()
            if role == 'employee':
                e = next((x for x in kv_get('core')['emps'] if x['c'] == emp), None)
                if not e: raise Err(400, 'Enter a valid employee code')
                br = e['b']
            if len(str(body.get('p', ''))) < 8: raise Err(400, 'Password must have at least 8 characters')
            if db.execute('SELECT 1 FROM users WHERE u=?', (n,)).fetchone(): raise Err(400, 'Username already exists')
            mkuser(n, str(body.get('name') or n)[:60], body['p'], role, br if role in ('branch', 'employee') else '', emp if role == 'employee' else '', 1)
            audit(u['u'], 'user created', '%s (%s)' % (n, role)); db.commit(); return dict(ok=1)
        if p == 'users/update' and m == 'POST':
            n = body.get('u'); r = db.execute('SELECT * FROM users WHERE u=?', (n,)).fetchone()
            if not r: raise Err(404, 'No such user')
            if 'p' in body:
                if len(str(body['p'])) < 8: raise Err(400, 'Password must have at least 8 characters')
                salt = secrets.token_hex(16); db.execute('UPDATE users SET salt=?,h=? WHERE u=?', (salt, hpw(body['p'], salt), n)); audit(u['u'], 'password reset', n)
            if 'active' in body:
                if n == u['u']: raise Err(400, 'You cannot disable your own account')
                db.execute('UPDATE users SET active=? WHERE u=?', (1 if body['active'] else 0, n))
                if not body['active']: db.execute('DELETE FROM sess WHERE u=?', (n,))
                audit(u['u'], 'user ' + ('enabled' if body['active'] else 'disabled'), n)
            db.commit(); return dict(ok=1)
        if p == 'users/employees' and m == 'POST':
            out = []
            for e in kv_get('core')['emps']:
                if db.execute('SELECT 1 FROM users WHERE role=? AND emp=?', ('employee', e['c'])).fetchone(): continue
                n, pw = re.sub(r'[^a-z0-9._-]+', '', str(e['c']).lower())[:30], secrets.token_urlsafe(6)
                if len(n) < 3 or db.execute('SELECT 1 FROM users WHERE u=?', (n,)).fetchone(): n = ('emp' + n)[:30]
                if db.execute('SELECT 1 FROM users WHERE u=?', (n,)).fetchone(): continue
                mkuser(n, e['n'][:60], pw, 'employee', e['b'], e['c'], 1); out.append(dict(c=e['c'], name=e['n'], branch=e['b'], u=n, p=pw))
            audit(u['u'], 'employee logins created', str(len(out))); db.commit(); return dict(created=out)
        if p == 'users/branches' and m == 'POST':
            out = []
            for b in kv_get('core')['br']:
                if db.execute('SELECT 1 FROM users WHERE role=? AND branch=?', ('branch', b)).fetchone(): continue
                n, pw = re.sub(r'[^a-z0-9]+', '-', b.lower()).strip('-')[:30] or 'branch', secrets.token_urlsafe(6)
                if db.execute('SELECT 1 FROM users WHERE u=?', (n,)).fetchone(): n += '-br'
                mkuser(n, b + ' branch', pw, 'branch', b, '', 1); out.append(dict(branch=b, u=n, p=pw))
            audit(u['u'], 'branch logins created', str(len(out))); db.commit(); return dict(created=out)
    raise Err(404, 'Not found')


class H(BaseHTTPRequestHandler):
    server_version = 'DSHRMS'
    def log_message(self, *a): pass

    def out(self, code, body, ctype='application/json', cookie=None, extra=()):
        b = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        for k, v in (('Content-Type', ctype + '; charset=utf-8'), ('Content-Length', str(len(b))), ('Cache-Control', 'no-store'),
                     ('X-Frame-Options', 'DENY'), *((('Strict-Transport-Security', 'max-age=31536000'),) if BEHIND else ()), ('X-Content-Type-Options', 'nosniff'), ('Referrer-Policy', 'no-referrer'),
                     ('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:")):
            self.send_header(k, v)
        for k, v in extra: self.send_header(k, v)
        if cookie is not None:
            self.send_header('Set-Cookie', 'sid=%s; HttpOnly; SameSite=Strict; Path=/; Max-Age=%d%s' % (cookie, 43200 if cookie else 0, '; Secure' if BEHIND else ''))
        self.end_headers(); self.wfile.write(b)

    def route(self, m):
        try:
            path = self.path.split('?')[0]
            if m == 'GET' and path in ('/', '/index.html'):
                return self.out(200, open(os.path.join(HERE, 'index.html'), 'rb').read(), 'text/html')
            if not path.startswith('/api/'): raise Err(404, 'Not found')
            body = {}
            if m == 'POST':
                if self.headers.get('X-Requested-With') != 'dshrms': raise Err(403, 'Bad request')
                n = int(self.headers.get('Content-Length') or 0)
                if n > 20_000_000: raise Err(413, 'Too large')
                body = json.loads(self.rfile.read(n) or b'{}')
            with LOCK:
                try: res = handle(self, m, path[5:], body, (self.headers.get('X-Forwarded-For', '').split(',')[0].strip() if BEHIND else '') or self.client_address[0])
                except Exception: db.rollback(); raise
            if isinstance(res, tuple): return self.out(200, res[1], res[2], extra=(('Content-Disposition', 'attachment; filename="export.xlsx"'),))
            ck = res.pop('_cookie', None) if isinstance(res, dict) else None
            self.out(200, json.dumps(res), cookie=ck)
        except Err as e: self.out(e.code, json.dumps({'error': e.msg}))
        except Exception: traceback.print_exc(); self.out(500, json.dumps({'error': 'Server error'}))
    do_GET = lambda self: self.route('GET')
    do_POST = lambda self: self.route('POST')


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--port', type=int, default=8080); ap.add_argument('--host', default='127.0.0.1'); a = ap.parse_args()
    with LOCK: bootstrap()
    print('DS HRMS running at http://%s:%d   (press Ctrl+C to stop)' % (a.host, a.port), flush=True)
    ThreadingHTTPServer((a.host, a.port), H).serve_forever()
